#!/opt/homebrew/bin/python3
import cgi, cgitb
print("Content-type:text/html")
print("")
name="Riya"
print("<html><head><title>First Page</title></head>")
print("<body bgcolor='khaki'><h1>Welcome to Python..",name,"</h1>")
print("</body></html>")
